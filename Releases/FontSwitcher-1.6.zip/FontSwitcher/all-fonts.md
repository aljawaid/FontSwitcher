# All Font Styles

**Default Fonts**  

![Default Fonts](../master/Screenshots/screenshot-default.png)

---

**Lato**  

![Lato](../master/Screenshots/screenshot-lato.png)

---

**Open Sans**  

![Open Sans](../master/Screenshots/screenshot-open-sans.png)

---

**Roboto Slab**  

![Roboto Slab](../master/Screenshots/screenshot-roboto-slab.png)

---

**Source Sans 3**  

![Source Sans 3](../master/Screenshots/screenshot-source-sans-3.png)

---

**Ubuntu Mono**  

![Ubuntu Mono](../master/Screenshots/screenshot-ubuntu-mono.png)

---

Read the full [**Changelog**](../master/changelog.md "See changes") or view the [**README**](../master/README.md "View README")
